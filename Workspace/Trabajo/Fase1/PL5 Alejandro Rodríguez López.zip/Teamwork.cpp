#include <iostream>
using namespace std;
extern "C" bool IsValidAssembly(int a, int b, int c);

/* Primera subrutina: StringBasedControl()
*	Pide una cadena por pantalla no declarada como String
*	Revisa que su longitud sea mayor que 3 y que su caracter en posici�n 2 es igual a su caracter en posici�n 0
* 
*	Pide otra cadena por pantalla no declarada como String
*	Revisa que la cadena sea "Dz7fFv"
* 
*	Ejemplo correcto:	aaaaaa
*						Dz7fFv
*/
void StringBasedControl() {
	char cadena1[20];
	cout << "Introduzca la cadena 1:\t";
	cin >> cadena1;

	if (strlen(cadena1) < 3 || cadena1[2] != cadena1[0]) {		//Longitud menor que 3 y posici�n 2 diferente de posici�n 0
		cout << "Entrada Incorrecta" << endl;
		exit(1);
	}
	char cadena2[20];
	cout << "Introduzca la cadena 2:\t";
	cin >> cadena2;							//Dz7fFv

	if (strcmp(cadena2, "Dz7fFv")) {							//Cadena igual a "Dz7fFv"
		cout << "Sayonara, baby" << endl;
		exit(1);
	}
}

/* Segunda subrutina: BitControl()
*	Pide 2 n�meros naturales por consola.
*	Revisa que el bit 8 del primer n�mero sea igual al bit 9 del segundo.
*	Revisa que los 16 bits de peso m�s alto del primer n�mero m�s los 16 de peso m�s bajo del segundo sea mayor que 8489.
*	Revisa que el bit 5 del primer n�mero sea 1
* 
*	Ejemplo correcto:	32
*						0
*/
void BitControl() {
	unsigned int a;
	unsigned int b;

	cout << "Introduzca dos valores naturales de 32 Bits:" << endl;
	cout << "Introduzca el primer valor:\t";
	cin >> a;
	cout << "Introduzca el segundo valor:\t";
	cin >> b;

	//Bit octavo igual a bit noveno de primer y segundo n�mero respectivamente
	b = (b >> 1);		//Mover bit noveno a posici�n octava
	if (((a & b & 256) != 256) && ((a & 256) != 0) || ((b & 256) != 0)) {	
		
		//				APLICACI�N LEYES DE DE MORGAN
		//((a & b & 256 == 256) && ((a & 256 == 0) && (b & 256 !== 0)))
		//((a & b & 256 != 256) && ((a & 256 == 0)  (b & 256 == 0)))
		//((a & b & 256 != 256) && ((a & 256 != 0)  (b & 256 != 0)))

		cout << "ENTRADA INCORRECTA" << endl;
		exit(1);
	}
	b = (b << 1);		//Devolver segundo n�mero a posici�n original

	//Los 16 bits de peso m�s alto del primer n�mero m�s los 16 de peso m�s bajo del segundo sea mayor que 8489
	if (((a & 4294901760) + (b & 65535)) < 8489) {															
		cout << "ACCESO INCORRECTO" << endl;
		exit(1);
	}

	
	//Bit quinto del primer n�mero es un 1
	if ((a & 32) != 32) {
		cout << "�ALTO AHI!" << endl;
		exit(1);
	}
	

}

/* Tercera subrutina: CheckInAsmbyFile()
*	Pide 3 enteros por consola.
*	Usando ensamblador en l�nea los pasar� a la funci�n IsValidAssembly() definida en Assembly-code.asm
* 
*	IsValidAssembly() comprobar�:
*		1- El resultado de la operaci�n XOR entre el segundo y tercer n�meros es 540377
*		2- El bit 20 del primer n�mero es 0
* 
*	Ejemplo correcto:	0
*						1556774
*						2097151
*/
void CheckInAsmbyFile() {
	int a;
	int b;
	int c;
	int* puntero = &a;

	cout << "Introduzca tres valores enteros de 32 bits: " << endl;			
	cout << "Introduzca el primer valor:\t";
	cin >> a;											
	cout << "Introduzca el segundo valor:\t";
	cin >> b;										
	cout << "Introduzca el tercer valor:\t";
	cin >> c;										
			
	//Test 1			Test 2
	//1048576			5
	//508198			1556774
	//540377			2097151
	//Expect: Fail		Expect: NoFail

	__asm {
		mov eax, a
		mov ebx, b
		mov ecx, c
		mov edx, puntero

		push edx			//Guardar registro

		push ecx			//Paso de parametros
		push ebx			
		push eax

		call IsValidAssembly			//Llamada funcion
		
		add esp, 12				

		pop edx				

		mov [edx],eax
	}

	if (a == 0) {
		cout << "Hubo un fallo" << endl;
		exit(1);
	}

}

/* Cuarta subrutina: InlineAssemblyAccess()
*	Pide un entero por consola.
*	Usando ensamblador en l�nea comprobar� que sus 16 bits m�s altos son iguales a sus 16 m�s bajos.
*	Visto el n�mero en binario, es un n�mero capic�a.
* 
*	Ejemplo correcto: -1
*/
void InlineAssemblyAccess() {
	cout << "Introduzca un entero de 32 bits:\t";
	signed int a;
	cin >> a;

	int* puntero = &a;

	__asm {
		mov ebx, a
		mov ecx, a
		mov esi, puntero
		mov edx, 0			//contador

		shl ecx, 1			//Movimiento
		
		bucle:
			mov eax, ecx	//Comparacion
			xor eax, ebx		
			and eax, 65536			
			cmp eax, 0				
			jne fin

			shl ecx, 1				//Movimientos
			shr ebx, 1				

			inc edx					
			cmp edx, 16		
			je fin					
			jne bucle				
			
		fin:
			mov [esi],edx
	}

	if (a != 16) {
		cout << "�Alto ah�!" << endl;
		exit(1);
	}

}

int main()
{
	//StringBasedControl();			//1
	//cout << endl;
	//BitControl();					//2
	//cout << endl;
	//CheckInAsmbyFile();				//3
	//cout << endl;
	InlineAssemblyAccess();			//4
	cout << endl;

	return 0;
}
